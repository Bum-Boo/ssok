import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "project"
OUT = ROOT / "out"
BASE = Path('/home/hojun/.local/share/agent-remote/jobs/20260922-163307-ssok-learned-feedback-component-regressi-7ca16050/work/project')
GODOT = '/home/hojun/.local/share/agent-remote/jobs/20260922-040405-ssok-godot-policy-923fd175/work/godot-bin'
BROWSER_BASE = Path('/home/hojun/.local/share/agent-remote/jobs/20260922-071716-ssok-v2-wasm-six-cases-ab31c8f5/work')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def execute(command, log, env, timeout=180):
    with log.open('w') as stream:
        result = subprocess.run(command, cwd=PROJECT, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=timeout)
    text = log.read_text()
    if result.returncode or re.search(r'^(?:SCRIPT ERROR|ERROR):', text, re.MULTILINE):
        raise RuntimeError(f'Failed {log}: exit {result.returncode}')
    return text


def main():
    OUT.mkdir()
    plan = json.loads((ROOT / 'plan.json').read_text())
    shutil.copy2(ROOT / 'plan.json', OUT / 'plan.json')
    shutil.copy2(ROOT / 'schedule.json', OUT / 'schedule.json')
    shutil.copy2(Path(__file__), OUT / 'run.py')
    if subprocess.check_output([GODOT, '--version'], text=True).strip() != '4.7.2.stable.official.ed1daf0bf':
        raise RuntimeError('Engine mismatch')
    shutil.copytree(BASE, PROJECT, ignore=shutil.ignore_patterns('.godot'))
    source = json.loads((ROOT / 'source-sha256.json').read_text())
    if any(digest(PROJECT / name) != value for name, value in source.items()):
        raise RuntimeError('Base source mismatch')
    for name, expected in plan['patch_sha256'].items():
        path = ROOT / 'patch' / name
        if digest(path) != expected:
            raise RuntimeError(f'Patch mismatch: {name}')
        target = PROJECT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
    gd_env = dict(os.environ, XDG_DATA_HOME=str(ROOT / 'userdata'),
                  XDG_CONFIG_HOME=str(ROOT / 'config'), XDG_CACHE_HOME=str(ROOT / 'cache'))
    templates = ROOT / 'userdata/godot/export_templates/4.7.2.stable'
    templates.mkdir(parents=True)
    for name, expected in plan['template_sha256'].items():
        if digest(ROOT / 'templates' / name) != expected:
            raise RuntimeError('Template mismatch')
        shutil.copy2(ROOT / 'templates' / name, templates / name)
    source_now = {str(p.relative_to(PROJECT)): digest(p) for p in PROJECT.rglob('*') if p.is_file()}
    (OUT / 'source-sha256.json').write_text(json.dumps(source_now, indent=2) + '\n')
    base = [GODOT, '--headless', '--path', str(PROJECT)]
    execute(base + ['--editor', '--import', '--quit'], OUT / 'import.log', gd_env)
    parity = []
    for restarted in [False, True]:
        pair = []
        for observed in [False, True]:
            flags = ['--restart'] if restarted else []
            flags += ['--observe'] if observed else []
            text = execute(base + ['--fixed-fps', '60', '--script',
                'tools/ci/native_parity.gd', '--', '--settle-frames=60', *flags],
                OUT / f'native-restart-{restarted}-observer-{observed}.log', gd_env)
            match = re.search(r'^NATIVE_PARITY=(.*)$', text, re.MULTILINE)
            if not match:
                raise RuntimeError('Missing native measurement')
            pair.append(json.loads(match.group(1)))
        parity.append({'restart': restarted, 'observer_off': pair[0], 'observer_on': pair[1], 'identical': pair[0] == pair[1]})
        (OUT / 'native-parity.json').write_text(json.dumps(parity, indent=2) + '\n')
        if pair[0] != pair[1]:
            raise RuntimeError('Read-only observer changed native results')
    print('Four native app checks pass; observer on/off pairs match exactly', flush=True)
    logs = ROOT / 'export-logs'
    logs.mkdir()
    execute(base + ['--language', 'en', '--script', 'tools/ci/browser_layout.gd', '--',
                    str(logs / 'browser-layout.json')], OUT / 'browser-layout.log', gd_env)
    shutil.copy2(logs / 'browser-layout.json', OUT / 'browser-layout.json')
    web = ROOT / 'web'
    web.mkdir()
    execute(base + ['--export-release', 'Web', str(web / 'index.html')], OUT / 'export.log', gd_env, 300)
    if not re.search(r'(?:const|var) GODOT_THREADS_ENABLED\s*=\s*false', (web / 'index.html').read_text()):
        raise RuntimeError('Threaded export')
    payload = {str(p.relative_to(web)): digest(p) for p in web.rglob('*') if p.is_file()}
    (OUT / 'web-payload.json').write_text(json.dumps(payload, indent=2) + '\n')
    browser_env = dict(os.environ)
    libs = str(BROWSER_BASE / '.browser-libs/usr/lib/x86_64-linux-gnu')
    browser_env['LD_LIBRARY_PATH'] = libs + (':' + browser_env['LD_LIBRARY_PATH'] if browser_env.get('LD_LIBRARY_PATH') else '')
    command = [str(BROWSER_BASE / '.venv/bin/python'), str(ROOT / 'tools/browser_matrix.py'),
               '--directory', str(web), '--output', str(OUT / 'browser'), '--schedule', str(ROOT / 'schedule.json')]
    print('Starting frozen six-case WASM matrix', flush=True)
    execute(command, OUT / 'browser.log', browser_env, 900)
    hashes = {str(p.relative_to(OUT)): digest(p) for p in OUT.rglob('*') if p.is_file()}
    (OUT / 'sha256.json').write_text(json.dumps(hashes, indent=2) + '\n')


if __name__ == '__main__':
    main()
