# Frozen heading candidate — actual Web application

The unchanged frozen candidate passes all six declared fresh/restart Chromium WebAssembly flows and all 123 checks. This is an isolated candidate export over committed 389f817, with the retained read-only multi-episode observer; it is not a clean production release.

Personal Himmel job `20260922-164956-ssok-learned-heading-wasm-six-cases-cd09b7c7` completed with exit 0 and released its resources. All 40 retrieved artifact hashes match. The retrieved plan, runner and schedule equal the submitted files. Four native executions give exact full-precision observer-off/on parity for both fresh and restart flows. Engine logs contain no ERROR or SCRIPT ERROR; all six browser console logs contain only startup information.

Each measured walk lasts exactly 720 physics intervals / 12 seconds, followed by 90 released-command intervals. Independently recomputed results are retained in `independent-audit.json`: forward travel 0.415939–0.431642 m, maximum absolute lateral travel 0.030166 m, maximum absolute heading change 8.412893 degrees, minimum uprightness 0.961239, and minimum stopped uprightness 0.999811. Both collision soles clear 0.5 mm in every case. Restart warmups retain their early-release outcomes. Schedule numbers are browser polling thresholds; actual observed frames remain in the raw results.

The candidate file SHA256 is `4a48d9c3616293559662181bd6c7bdc558e5a921ff2347f38d0e7894c0100a2d`; the application reports canonical policy fingerprint `d16287993d2e93cb49a9ec7beaf9a443273164ed36c3e2df74afe6a1bfb4d72d`. File hashing and application policy fingerprinting are distinct. Graph `c1920876…` and runtime `0a269bde…` remain unchanged.

All six original after-stop screenshots were visually inspected: the full robot remains upright and visible between the panels, with its board visible. This does not certify all four languages or all compact layouts.

The separate frozen cohort remains 255/256 with one fall, versus reference 251/256 with five falls. These six browser cases do not remove that limitation. Actual native-app verification is retained at `../ssok-learned-heading-app-results/REPORT.md`. Production integration, updated current-policy media and subsequent clean export verification remain outstanding. No production source, UI strings or locale files changed in this verification.
