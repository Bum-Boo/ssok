import concurrent.futures, hashlib, json, os, re, shutil, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PROJECT=ROOT/'project'
OUT=ROOT/'out'
GODOT=Path('/home/hojun/.local/share/agent-remote/jobs/20260922-040405-ssok-godot-policy-923fd175/work/godot-bin')
BASE=Path('/home/hojun/.local/share/agent-remote/jobs/20260922-163307-ssok-learned-feedback-component-regressi-7ca16050/work/project')
POLICY='assets/policies/yaw_biped_bounded_v2.json'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def source_check(manifest):
    values={n:digest(PROJECT/n) if (PROJECT/n).is_file() else None for n in manifest}
    return {'files':len(manifest),'sha256':values,'mismatches':{n:{'expected':v,'actual':values[n]} for n,v in manifest.items() if values[n]!=v}}
def run_process(name,args,timeout=240):
    folder=OUT/name;folder.mkdir()
    env=os.environ.copy()
    for k in ('DATA','CONFIG','CACHE'):
        d=folder/('xdg_'+k.lower());d.mkdir();env['XDG_'+k+'_HOME']=str(d)
    started=time.time();timed_out=False
    try:
        p=subprocess.run([str(GODOT),*args],env=env,cwd=PROJECT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=timeout)
        log=p.stdout;code=p.returncode
    except subprocess.TimeoutExpired as e:
        timed_out=True;code=None;log=e.stdout or b''
        if isinstance(log,bytes):log=log.decode(errors='replace')
    (folder/'godot.log').write_text(log)
    errors=re.findall(r'^(?:SCRIPT ERROR|ERROR):.*$',log,re.M)
    return {'name':name,'command':[str(GODOT),*args],'exit_code':code,'timeout':timed_out,'engine_error':bool(errors),'engine_errors':errors,'seconds':time.time()-started},log
OUT.mkdir()
plan=json.loads((ROOT/'plan.json').read_text());manifest=json.loads((ROOT/'source-sha256.json').read_text())
assert digest(ROOT/'frozen_candidate.json')==plan['candidate_sha256']
for name in ('plan.json','source-sha256.json','frozen_candidate.json','run.py'):shutil.copy2(ROOT/name,OUT/name)
shutil.copytree(BASE,PROJECT,ignore=shutil.ignore_patterns('.godot'))
shutil.copytree(ROOT/'original-tests',PROJECT,dirs_exist_ok=True)
before=source_check(manifest);write('source-before-policy.json',before);assert not before['mismatches']
shutil.copy2(ROOT/'frozen_candidate.json',PROJECT/POLICY)
expected={**manifest,POLICY:plan['candidate_sha256']}
after=source_check(expected);write('source-candidate.json',after);assert not after['mismatches']
engine=subprocess.check_output([str(GODOT),'--version'],text=True).strip();write('engine.json',{'version':engine,'binary_sha256':digest(GODOT)})
assert engine=='4.7.2.stable.official.ed1daf0bf'
imp,log=run_process('import',['--headless','--path',str(PROJECT),'--editor','--import'],timeout=300)
write('import.json',imp);assert imp['exit_code']==0 and not imp['engine_error'] and not imp['timeout']
def run_case(case):
    args=['--headless','--path',str(PROJECT),'--fixed-fps','60','--script',case['script']]
    if case['args']:args+=['--',*case['args']]
    result,log=run_process(case['name'],args)
    match=re.search(r'learned_app_check: (\d+) checks, (\d+) failures',log)
    if case['script'].endswith('learned_app_check.gd'):
        result['checks']=int(match[1]) if match else None
        result['failures']=int(match[2]) if match else None
        result['terminal_summary_pass']=bool(match and int(match[1])==case['expected_checks'] and int(match[2])==0)
        result['measurement_lines']=re.findall(r'^LEARNED_APP .*$',log,re.M)
    elif case['name']=='blender_camera_check':result['terminal_summary_pass']='blender_camera_check: PASS' in log
    else:
        match=re.search(r'viewport_framing_check: (\d+) checks, (\d+) failures',log)
        result['checks']=int(match[1]) if match else None
        result['failures']=int(match[2]) if match else None
        result['terminal_summary_pass']=bool(match and int(match[1])>0 and int(match[2])==0)
    result['passed']=result['exit_code']==0 and not result['timeout'] and not result['engine_error'] and result['terminal_summary_pass']
    write(case['name']+'/result.json',result)
    print(json.dumps(result),flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=plan['workers']) as pool:results=list(pool.map(run_case,plan['cases']))
final=source_check(expected);write('source-after-tests.json',final)
summary={'source_commit':plan['source_commit'],'candidate_sha256':plan['candidate_sha256'],'engine':engine,'cases':len(results),'passed':sum(r['passed'] for r in results),'failed':sum(not r['passed'] for r in results),'source_mismatches':len(final['mismatches']),'results':results}
write('summary.json',summary)
files={str(p.relative_to(OUT)):digest(p) for p in sorted(OUT.rglob('*')) if p.is_file() and not any(x.startswith('xdg_') for x in p.relative_to(OUT).parts)}
write('sha256.json',files)
print(json.dumps(summary),flush=True)
sys.exit(0 if summary['failed']==0 and not final['mismatches'] else 1)
