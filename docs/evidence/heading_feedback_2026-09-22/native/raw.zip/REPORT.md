# Frozen heading policy: native actual-application validation

The same frozen candidate passed all 12 declared native application cases and both original camera suites in one isolated managed Himmel job. This is candidate validation only; production remains unchanged.

- Source commit: `389f817deacbf62dfb3ff73dfa132301e4be7329`.
- Candidate file SHA256: `4a48d9c3616293559662181bd6c7bdc558e5a921ff2347f38d0e7894c0100a2d`.
- Job: `20260922-165510-ssok-learned-heading-native-app-twelve-b42aa5fa`, completed with exit 0 and resources released. Four worker processes; no retry or duplicate job.
- Exact Godot `4.7.2.stable.official.ed1daf0bf`, headless native 60 Hz, real application main scene. Each case uses fresh isolated user data/config/cache directories.
- All 486 baseline source/test hashes independently match the commit. Original tests and their UIDs were copied verbatim. Before/after source audits confirm the sole changed source file is `assets/policies/yaw_biped_bounded_v2.json`.
- All 39 hashed output artifacts match after retrieval. All 29 Godot logs, including import and duplicate user logs, contain zero `ERROR:` or `SCRIPT ERROR:` lines. No user-facing strings or localization changed.

The original `tests/learned_app_check.gd` runs 737 assertions per case: actual W input reaches the controller; 720 physical frames achieve at least 0.30 m forward with at most 0.10 m lateral and 30 degrees yaw; upright/height remain above the unchanged standing thresholds; the robot stays visible; releasing W gives a zero command and upright robot after 90 frames; the assembly graph remains unchanged; edit framing restores; mismatched edited geometry is rejected. Restart cases use the original 180-frame walk and 60-frame pause. Neither timing nor assertions were edited.

| Settle frames | Restart | Forward m | Lateral m | Yaw deg | Min upright | Min height m | Checks / failures |
| ---: | :---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | false | 0.42082 | 0.05629 | -3.179 | 0.9581 | 0.1278 | 737 / 0 |
| 0 | true | 0.42981 | 0.03241 | -3.960 | 0.9640 | 0.1287 | 737 / 0 |
| 1 | false | 0.42176 | 0.05779 | -3.065 | 0.9581 | 0.1278 | 737 / 0 |
| 1 | true | 0.43800 | 0.01239 | 7.399 | 0.9648 | 0.1294 | 737 / 0 |
| 60 | false | 0.42069 | 0.02566 | 10.467 | 0.9654 | 0.1288 | 737 / 0 |
| 60 | true | 0.41783 | 0.00151 | 1.529 | 0.9660 | 0.1291 | 737 / 0 |
| 121 | false | 0.42887 | 0.03487 | -4.582 | 0.9601 | 0.1290 | 737 / 0 |
| 121 | true | 0.42389 | 0.02889 | 5.834 | 0.9650 | 0.1292 | 737 / 0 |
| 180 | false | 0.43071 | 0.01862 | -10.153 | 0.9652 | 0.1288 | 737 / 0 |
| 180 | true | 0.41416 | -0.01036 | -8.686 | 0.9792 | 0.1289 | 737 / 0 |
| 257 | false | 0.42127 | -0.00200 | -2.050 | 0.9650 | 0.1290 | 737 / 0 |
| 257 | true | 0.40961 | -0.01590 | 2.505 | 0.9815 | 0.1285 | 737 / 0 |

The original `blender_camera_check.gd` reports PASS, and `viewport_framing_check.gd` reports 62,660 checks / 0 failures. These separate suites cover projection/picking and the application framing/resize contracts; the 12 walking cases themselves do not assert ray picking or foot air time. This headless run is not a visual screenshot review or Web result.

The fresh paired 256-condition evaluator results remain separate: shipping 251/256 with five falls, selected 255/256 with one fall. This native 12/12 result does not erase that failure or certify backward/turning/general assemblies. Root owns the same-candidate Web evaluation and any later production integration/clean release gates.

Reproduction inputs are `plan.json`, `run.py`, `source-sha256.json` and `frozen_candidate.json`; raw logs, exact commands and results are retained in each case directory. `independent-audit.json` and `job-info.json` record retrieval verification and terminal state. Production local kit work was not touched.
