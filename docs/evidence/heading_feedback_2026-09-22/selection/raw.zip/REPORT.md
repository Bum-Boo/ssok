# Learned feedback component regression

Completed personal Himmel job `20260922-163307-ssok-learned-feedback-component-regressi-7ca16050` with exit0; resources released and all output fetched. Source is a narrow export of committed389f817,480 file hashes verified remotely. All1171 retained artifact hashes match locally; raw engine logs have no ERROR/SCRIPT ERROR. Four baseline episodes reproduce every retained scalar/vector exactly before the384 regression episodes.

This is regression on128 already observed conditions, following24 four-case counterfactuals. It is development/checkpoint selection data, not new held-out evidence. The carrier, inference class, graph/runtime fingerprints, actuator cap, gravity, collisions and success gates remain unchanged. Only one of three learned ankle feedback components is taken from the previous transferred policy at a time.

| Candidate | Strict passes | Falls |
|---|---:|---:|
| old_position | 123/128 | 4 |
| old_velocity | 124/128 | 4 |
| old_heading | 128/128 | 0 |

The heading-only reversion passes128/128 with zero falls and minimum successful uprightness0.94643. The other two candidates increase falls and are rejected; all failure seeds/metrics remain in summary.json. Strict success also requires min uprightness0.85, min height0.09m and both soles clearing0.5mm, in addition to the unchanged12-second command-relative0.30m/0.10m/30degree gate.

The heading candidate is selected and frozen for a separate256-condition comparison against the shipping policy, with a predeclared new seed range and fresh processes. Its provenance calls this post-training coefficient recombination, not new CEM training. Do not adopt based solely on this selected cohort; fresh evaluation, actual-app and Web remain unverified. Production bundle is unchanged.

Fresh plan: `/home/bumboo/Projects/ssok-learned-heading-frozen-probe/plan.json`. Frozen candidate SHA256: `4a48d9c3616293559662181bd6c7bdc558e5a921ff2347f38d0e7894c0100a2d`.
