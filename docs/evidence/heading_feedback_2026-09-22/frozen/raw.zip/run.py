from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "project"
OUT = ROOT / "out"
GODOT = "/home/hojun/.local/share/agent-remote/jobs/20260922-040405-ssok-godot-policy-923fd175/work/godot-bin"
EXPECTED_ENGINE = "4.7.2.stable.official.ed1daf0bf"
OUT.mkdir(exist_ok=True)
PLAN = json.loads((ROOT / "plan.json").read_text())


def execute(command, log, env=None):
    result = subprocess.run(command, cwd=PROJECT, env=env, capture_output=True, text=True, timeout=120)
    text = result.stdout + result.stderr
    log.write_text(text)
    if result.returncode or re.search(r"^(?:SCRIPT ERROR|ERROR):", text, re.MULTILINE):
        raise RuntimeError(f"Engine failure, exit {result.returncode}: {log}")


def episode(name, case, policy):
    directory = OUT / name
    directory.mkdir()
    source = directory / "input.json"
    target = directory / "result.json"
    source.write_text(json.dumps({"episodes": [{**case, "policy": policy}]}))
    env = dict(os.environ)
    for key in ("XDG_DATA_HOME", "XDG_CONFIG_HOME", "XDG_CACHE_HOME"):
        env[key] = str(directory / key.lower())
    execute([GODOT, "--headless", "--path", str(PROJECT), "--fixed-fps", "60", "--script",
             "tools/godot/evaluate_learned_policy.gd", "--", "--input", str(source),
             "--output", str(target)], directory / "engine.log", env)
    result = json.loads(target.read_text())["episodes"][0]
    if "error" in result:
        raise RuntimeError(result)
    return result


def strict_pass(result):
    return (result["relative_success"] and result["min_upright"] >= .85
            and result["minimum_height"] >= .09
            and all(v > .0005 for v in result["maximum_foot_clearance_m"]))


def main():
    engine = subprocess.check_output([GODOT, "--version"], text=True).strip()
    if engine != EXPECTED_ENGINE:
        raise RuntimeError(engine)
    source = json.loads((ROOT / "source-sha256.json").read_text())
    differences = [name for name, digest in source.items()
                   if hashlib.sha256((PROJECT / name).read_bytes()).hexdigest() != digest]
    if differences:
        raise RuntimeError(differences)
    shutil.copy2(ROOT / "plan.json", OUT / "plan.json")
    shutil.copy2(ROOT / "source-sha256.json", OUT / "source-sha256.json")
    shutil.copy2(Path(__file__), OUT / "run.py")
    execute([GODOT, "--headless", "--path", str(PROJECT), "--editor", "--import", "--quit"], OUT / "import.log")
    parity = []
    for index, item in enumerate(PLAN["parity"]):
        actual = episode(f"parity-{index}", item["case"], item["policy"])
        difference = {k: [v, actual.get(k)] for k, v in item["expected"].items() if v != actual.get(k)}
        parity.append({"case": item["case"], "policy": item["name"], "differences": difference})
        (OUT / "parity.json").write_text(json.dumps(parity, indent=2))
        if difference:
            raise RuntimeError(f"Baseline parity failed: {difference}")
    print("All four retained baseline episodes exactly reproduced", flush=True)
    summary = []
    all_results = []
    for name, policy in PLAN["variants"].items():
        def run_case(case):
            return episode(f"{name}-{case['seed']}", case, policy)
        with ThreadPoolExecutor(max_workers=PLAN["workers"]) as pool:
            results = list(pool.map(run_case, PLAN["cases"]))
        all_results.append({"variant": name, "results": results})
        row = {"variant": name, "episodes": len(results),
               "strict_passes": sum(strict_pass(r) for r in results),
               "relative_passes": sum(r["relative_success"] for r in results),
               "falls": sum(r["fallen"] for r in results),
               "failures": [r for r in results if not strict_pass(r)],
               "minimum_successful_upright": min(r["min_upright"] for r in results if strict_pass(r))}
        summary.append(row)
        (OUT / "results.json").write_text(json.dumps(all_results, indent=2) + "\n")
        (OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
        print(json.dumps(row), flush=True)
    manifest = {str(p.relative_to(OUT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in OUT.rglob("*") if p.is_file() and "xdg_" not in str(p.relative_to(OUT))}
    (OUT / "sha256.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
