# Frozen heading-feedback comparison: new256 conditions

The selected candidate passes **255/256** new conditions with **one fall**. The current shipping policy passes **251/256** with **five falls** on the same cases. Five reference failures improve and one previously successful case fails; the other250cases pass under both policies. This is an observed cohort improvement, not a guarantee of every start or restart.

| Policy | Fresh | Restart | Falls |
|---|---:|---:|---:|
| Shipping reference | 127/128 | 124/128 | 5 |
| Frozen heading candidate | 127/128 | 128/128 | 1 |

The candidate was selected only from the preceding development regression of three single-component counterfactuals. It retains the newly trained position/velocity feedback and substitutes the previous policy's learned heading coefficient. This is post-training coefficient recombination, not a new CEM training run. The full provenance and candidate were frozen before these cases, file SHA256 `4a48d9c3616293559662181bd6c7bdc558e5a921ff2347f38d0e7894c0100a2d`.

`plan.json` declares Python Random seed202609221638 and disjoint ranges990100000–990100127 and990200000–990200127, 0–300frame settling,1–300frame warmup/pause and±0.004m/s initial velocity perturbation. Each case runs in a fresh Godot4.7.2 process. The exact389 committed base source and four paired development outcomes are verified before execution. All original numeric outputs match those four expected baselines. Policy metadata changes do not affect those trajectories.

Strict success adds minimum uprightness0.85, minimum height0.09m and both soles clearing0.5mm to the unchanged12-second command-relative0.30m forward/0.10m lateral/30degree gate. All reported passes satisfy both strict and original checks. The candidate's minimum successful uprightness is0.932924. All failures remain in summary.json and the per-case raw directories.

The remaining candidate failure is fresh seed990100126 after a1.6-second settle: it falls after6.8seconds, minimum uprightness0.446221 and height0.080450m. It did not fall during preparation. It is not removed, retried for a favourable result or relabeled because other cases pass. The reference succeeds on this case.

Personal Himmel job `20260922-164123-ssok-learned-heading-frozen-comparison-7b79063a` completed exit0 with resources released and was fetched. Local audit matches all1555 artifact hashes, every engine log has zero ERROR/SCRIPT ERROR, and all four baseline comparisons are exact. See independent-audit.json and paired-comparison.json. Source/probe plans and inputs preserve reproducibility.

Production remains unchanged. Actual native application and six-case WASM verification are separate pending gates before adoption. New data may be used as future development data only with that change in status made explicit; it must not continue to be called unseen after tuning against it.
